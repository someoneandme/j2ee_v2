package com.test.spring2_aop;

import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * 2014年10月8日 13:35:12
 */
public class TestMain {

	public static void main(String[] args) {
		String xmlPath = "/applicationContext-aop.xml";
		ApplicationContext context = new ClassPathXmlApplicationContext(xmlPath);

		System.out.println(context);

		CustomerBo customerBo = (CustomerBo) context.getBean("customerBoImpl");
		System.out.println(customerBo);
		System.out.println(customerBo.getClass()); // 已经是AOP后的代理对象

		Map<String, CustomerBo> map = context.getBeansOfType(CustomerBo.class);
		System.out.println(map);
		// 这里可以看到，尽管有AOP，但是该类型最终在spring容器中的对象只有一个，就是AOP处理后的那个
		System.out.println("customerBO num:" + map.size());
		
		// 获得spring容器中所有定义的bean
		System.out.println("==============================");
		String beanNames[] = context.getBeanDefinitionNames();
		for(String beanName : beanNames) {
			System.out.print(beanName);
			Object obj = context.getBean(beanName);
			System.out.println(":" + obj.getClass());
		}
	}
}
